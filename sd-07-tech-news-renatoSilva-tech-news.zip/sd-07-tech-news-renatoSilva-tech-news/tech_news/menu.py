# Requisito 12
def analyzer_menu():
    """Seu código deve vir aqui"""
